export class Constants {

    USER_DETAIL = {
        USER_NAME: 'system-user',
        USER_ID: 1
    }
}