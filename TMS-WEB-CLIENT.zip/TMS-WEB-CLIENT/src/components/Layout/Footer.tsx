import React from "react";

export default function Footer() {
    return (
        <>
            <div style={{ display: 'flex', justifyContent: 'center' }}>
                <b>Powered By Gloud Academy</b>
            </div>
            </>
    );
}