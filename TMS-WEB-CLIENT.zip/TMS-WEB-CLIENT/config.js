module.exports = class Configuration {
    GATEWAY_URL = 'http://localhost:3000/api/rest/tms/dataaccess/1.0.0/';
    GATEWAY_USERNAME = 'QP0192923232LD';
    GATEWAY_PASSWORD = '927NBGJJ0283HKA74782';
    HEADERS = {
        MERCHANT_KEY: 'BASE-MERCHANT-KEY',
        TENANT_KEY: 'BASE-TENANT-KEY'
    }
}