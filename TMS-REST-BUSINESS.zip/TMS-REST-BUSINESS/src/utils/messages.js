/**
* CreatedBy    : Dinesh
* CreatedTime  : July 29 2023
* ModifiedBy   : Ayerathammal 
* ModifiedTime : OCT 06 2023
* Description : This file contains all messages for application
 */
module.exports = class messages {

	/**
	 * Common messages
	 */
	MESSAGE_SERVICE_RUNNING_SUCESSFULLY = "TMS Rest Business is now running on";
	MESSAGE_AVAILABILITY_NOT_ENABLED = "Avaliability flag has not been enabled";
	MESSAGE_MISSING_REQUEST_HEADER = "Missing 'TenantKey' or 'MerchantKey' or 'AuthKey' or 'ContactPeronKey' or 'ApplicationKey' or 'IntanceKey' in the request headers";
	MESSAGE_INVALID_REQUEST_HEADERS = "'TenantKey' or 'MerchantKey' in the request headers is not valid";
	MESSAGE_BASIC_AUTH_FAILED = "Basic authentication failed, incorrect username or password";

	MESSAGE_BASE_SETUP_SUCESSFULL = "The given data has been inserted in the database Successfully...!"
}