module.exports = class constants {

    /**
     * Common messages
     */


}